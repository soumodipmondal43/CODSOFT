def get_number(prompt):
  """
  This function prompts the user for a number and ensures it's a valid float.
  """
  while True:
    try:
      number = float(input(prompt))
      return number
    except ValueError:
      print("Invalid input. Please enter a number.")

def get_operation():
  """
  This function prompts the user for an operation and validates it.
  """
  while True:
    operation = input("Enter operation (+, -, *, /): ")
    if operation in ['+', '-', '*', '/']:
      return operation
    else:
      print("Invalid operation. Please enter +, -, *, or /.")

def calculate(num1, num2, operation):
  """
  This function performs the calculation based on the chosen operation.
  """
  if operation == '+':
    return num1 + num2
  elif operation == '-':
    return num1 - num2
  elif operation == '*':
    return num1 * num2
  elif operation == '/':
    if num2 == 0:
      print("Error: Division by zero!")
      return None  # Handle division by zero error
    else:
      return num1 / num2

def main():
  """
  This function is the main loop for the calculator program.
  """
  print("Welcome to the Simple Calculator!")
  while True:
    num1 = get_number("Enter the first number: ")
    num2 = get_number("Enter the second number: ")
    operation = get_operation()

    result = calculate(num1, num2, operation)

    if result is not None:
      print(f"{num1} {operation} {num2} = {result}")

    # Ask user if they want to continue
    choice = input("Do you want to perform another calculation? (yes/no): ")
    if choice.lower() != 'yes':
      break

  print("Thank you for using the Simple Calculator!")

if __name__ == "__main__":
  main()
