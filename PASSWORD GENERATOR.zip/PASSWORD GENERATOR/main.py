import string
import random

def generate_password(length, use_uppercase=True, use_numbers=True, use_special_chars=True):
    lowercase_letters = string.ascii_lowercase
    uppercase_letters = string.ascii_uppercase if use_uppercase else ''
    numbers = string.digits if use_numbers else ''
    special_chars = string.punctuation if use_special_chars else ''

    all_chars = lowercase_letters + uppercase_letters + numbers + special_chars

    if length < 4:
        print("Password length should be at least 4 characters")
        return None

    if len(all_chars) == 0:
        print("At least one character set should be enabled")
        return None

    password = ''.join(random.choice(all_chars) for i in range(length))
    return password

# Prompt the user to specify the desired length of the password
length = int(input("Enter the desired length of the password (minimum 4): "))

# Prompt the user to specify the complexity of the password
use_uppercase = input("Use uppercase letters? (y/n): ").lower() == 'y'
use_numbers = input("Use numbers? (y/n): ").lower() == 'y'
use_special_chars = input("Use special characters? (y/n): ").lower() == 'y'

# Generate the password
generated_password = generate_password(length, use_uppercase, use_numbers, use_special_chars)

# Display the password
print("Generated password: ", generated_password)